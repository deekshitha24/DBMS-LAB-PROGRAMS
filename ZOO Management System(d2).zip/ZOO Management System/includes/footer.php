<div class="footer-section">
				<div class="container">
					<div class="footer-top">
						<p>&copy; <?php echo date('Y')?> Zoo Management System by d2 </p>
					</div>
				</div>
			</div>